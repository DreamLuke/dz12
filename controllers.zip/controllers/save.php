<?php


if(isset($_GET['operator'])){

    //добавление города
    if($_GET['operator'] == 'addcity'){
        include_once $_SERVER['DOCUMENT_ROOT'].'/models/cities.php';

        $cityClass = new Cities();

        if(!empty($_POST['id'])){
            $result = $cityClass->update($_POST);
        }else{
            unset($_POST['id']);
            $result = $cityClass->insert($_POST);
        }

        if($result){
            //echo 'данные сохранены!';
            header('Location: ../index.php');
        }
    }

    //добавление-редакитрование автомобиля
    if($_GET['operator'] == 'addcar'){
        include_once $_SERVER['DOCUMENT_ROOT'].'/models/cars.php';

        $carClass = new Cars();

        if(!empty($_POST['id'])){
            if(!empty($_POST['name']) && !empty($_POST['manufacture_year']) && !empty($_POST['city_id'])) {
                $result = $carClass->update($_POST);
            }
        }else{
            unset($_POST['id']);
            if(!empty($_POST['name']) && !empty($_POST['manufacture_year']) && !empty($_POST['city_id'])) {
                $result = $carClass->insert($_POST);
            }
        }

        if($result){
            // echo 'данные о машине сохранены!';
            header('Location: ../carsList.php');
        }

    }

}

?>