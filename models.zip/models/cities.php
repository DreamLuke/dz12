<?php

include_once $_SERVER['DOCUMENT_ROOT'].'/models/db.php';

Class Cities extends db{

    public $table_name = 'cities' ;



}

?>