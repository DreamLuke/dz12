<?php

include_once $_SERVER['DOCUMENT_ROOT'].'/models/db.php';

Class Cars extends db{

    public $table_name = 'cars';

}

?>